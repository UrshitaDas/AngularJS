var app = angular.module("serviceApp",[]);

app.factory("trainList",function($http,$log){
	return{
		retrieveTrain : function(success){
			$http({
					method:'GET',
					url:'data/trains.json'
				})
				.success(function(data,status,headers,config){
					success(data); // Callback function
					$log.info(data,status,headers(),config);
				})
				.error(function(data,status,headers,config){
					$log.warn(data,status,headers(),config);
				}
			);
		} 
	}
})

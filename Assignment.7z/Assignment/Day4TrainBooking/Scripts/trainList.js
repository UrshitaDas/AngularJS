var app = angular.module("serviceApp",[]);

app.config(function($provide)
{
	$provide.provider("retrieveTrain",function()
	{
		return
		{
			$get : function()
			{
				return
				{
					trains : 
					[
						{
						"trainId":10100,
						"source":"Pune",
						"destination":"Mumbai"
						},
						{
						"trainId":10101,
						"source":"Bangalore",
						"destination":"Hyderabad"
						},
						{
						"trainId":10108,
						"source":"Kolkata",
						"destination":"Mumbai"
						},
						{
						"trainId":10110,
						"source":"Kolkata",
						"destination":"Pune"
						}
						
					]
				}
			}
		}
	})
})